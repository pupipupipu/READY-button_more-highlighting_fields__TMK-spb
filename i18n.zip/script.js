define(["jquery"], function ($) {
  var CustomWidget = function () {
    var self = this,
      system = self.system;
    this.callbacks = {
      settings: function () {},
      init: function () {
        const userData = {
          users: {
            8459971: {
              mail: "oksanaom@yandex-team.ru",
              staff: "oksanaom",
              role: "Руководитель группы продаж",
              name: "Оксана Омармагомедова",
              team: "Команда: Мария Енина",
            },
            10239285: {
              mail: "gaepkulova-a@yandex-team.ru",
              staff: "gaepkulova-a",
              role: "Менеджер по продажам",
              name: "Алия Гаепкулова",
              team: "Команда: Оксана Омармагомедова",
            },
            10369845: {
              mail: "ben4rn@yandex-team.ru",
              staff: "ben4rn",
              role: "Менеджер по продажам",
              name: "Владимир Лазарев",
              team: "Команда: Оксана Омармагомедова",
            },
            10359733: {
              mail: "pnmaslova@yandex-team.ru",
              staff: "pnmaslova",
              role: "Менеджер по продажам",
              name: "Полина Маслова",
              team: "Команда: Оксана Омармагомедова",
            },
            9594090: {
              mail: "bakhodurov@yandex-team.ru",
              staff: "bakhodurov",
              role: "Руководитель группы продаж",
              name: "Азим Баходуров",
              team: "Команда: Мария Енина",
            },
            10114305: {
              mail: "ekaterina4412@yandex-team.ru",
              staff: "ekaterina4412",
              role: "Менеджер по продажам",
              name: "Екатерина Карпова",
              team: "Команда: Азим Баходуров",
            },
            10180277: {
              mail: "piliptsovge@yandex-team.ru",
              staff: "piliptsovge",
              role: "Менеджер по продажам",
              name: "Герман Пилипцов",
              team: "Команда: Азим Баходуров",
            },
            10287025: {
              mail: "olgasuhomlina@yandex-team.ru",
              staff: "olgasuhomlina",
              role: "Менеджер по продажам",
              name: "Ольга Сухомлина",
              team: "Команда: Азим Баходуров",
            },
            10637977: {
              mail: "razvivatel@yandex-team.ru",
              staff: "razvivatel",
              role: "Менеджер по продажам",
              name: "Руслан Долматов",
              team: "Команда: Азим Баходуров",
            },
						//ТЕСТ НА СЕБЕ
            9999129: {
              mail: "ab102030@yandex-team.ru",
              staff: "ab102030",
              role: "Менеджер по продажам",
              name: "Андрей Бородин",
              team: "Команда: Азим Баходуров",
            },
          },
        };

        //Сам элемент лида, в который юзер заходит
        let cardHolderElement = document.getElementById("card_holder");

        //ID юзера
        let idUser = document.querySelector(".n-avatar.js-left-avatar").id;

        //Имя пользователя
        let nameUser = document
          .querySelector(".nav__top__userbar__userinfo__username")
          .textContent.trim();

        // Выводим ошибку, если элемент не найден
        if (!cardHolderElement) {
          // Элемент не найден, выводим сообщение об ошибке
          console.error('Элемент с ID "card_holder" не найден.');
        } else {
          clickToMore();
        }

        //// Отслеживание изменения стилей card_holder
        // Создаем экземпляр MutationObserver с функцией обратного вызова
        let observer = new MutationObserver(function (mutationsList) {
          for (let mutation of mutationsList) {
            if (
              mutation.type === "attributes" &&
              mutation.attributeName === "style"
            ) {
              // Свойство style элемента было изменено
              let styleCardHolder = window.getComputedStyle(cardHolderElement);
              let displayValueCardHolder =
                styleCardHolder.getPropertyValue("display");

              // Проверяем, если display не равен 'none', то выполняем действия
              if (displayValueCardHolder !== "none") {
                // Ваш код для случая, когда display отличен от 'none'
                clickToMore();
              }
            }
          }
        });

        // Настраиваем наблюдение для изменений атрибута style
        observer.observe(cardHolderElement, { attributes: true });
        //// Отслеживание изменения стилей card_holder

        function clickToMore() {
          // Проверяем, есть ли пользователь с указанным ID и его роль подходит
          if (
            userData.users[idUser] &&
            (userData.users[idUser].role === "Менеджер по продажам" ||
              userData.users[idUser].role === "Руководитель группы продаж")
          ) {
            //exp
            waitForSelector(() => {
							let potentialExpGeneral = document.querySelector('[data-id="656673"]');
							potentialExpGeneral.style.borderBottom = "3px solid rgb(235 235 248)";

							let potentialExpFact = document.querySelector('[data-id="701657"]');
							potentialExpFact.style.borderBottom = "3px solid rgb(235 235 248)";
						}, '[data-id="656673"]');
            //ndd
            waitForSelector(() => {
							let potentialNddGeneral = document.querySelector('[data-id="130985"]');
							potentialNddGeneral.style.borderBottom = "3px solid rgb(235 235 248)";

							let potentialNddFact = document.querySelector('[data-id="701659"]');
							potentialNddFact.style.borderBottom = "3px solid rgb(235 235 248)";
						}, '[data-id="130985"]');
            //carg
            waitForSelector(() => {
							let potentialCargoGeneral = document.querySelector('[data-id="656709"]');
							potentialCargoGeneral.style.borderBottom = "3px solid rgb(235 235 248)";

							let potentialCargoFact = document.querySelector('[data-id="701663"]');
							potentialCargoFact.style.borderBottom = "3px solid rgb(235 235 248)";
						}, '[data-id="656709"]');

            waitForSelector(() => {
              const allPhones = document.querySelectorAll(
                '[data-pei-code="phone"]'
              );

              allPhones.forEach((phone) => {
                phone.style.borderBottom = "3px solid rgb(235 235 248)";
              });

              const allEmails = document.querySelectorAll(
                '[data-type="email"]'
              );

              allEmails.forEach((email) => {
                email.style.borderBottom = "3px solid #d5d5f8";
              });

              for (let i = 0; i < 3; i++) {
                buttonSecondMore = document.querySelectorAll(
                  ".linked-form__field-shower-text.js-linked-show-all-fields"
                )[1];
                buttonSecondMore.click();
              }
            }, ".linked-form__field-shower-text.js-linked-show-all-fields");
          }
        }

        /////// Ожидание появления селектора
        function waitForSelector(workFunction, selector) {
          // Передаваемый элемент
          const targetElement = document.querySelector(selector);

          if (targetElement) {
            workFunction();
          } else {
            // Создаем экземпляр MutationObserver с колбэком, который будет вызываться при изменениях
            const observer = new MutationObserver((mutationsList, observer) => {
              // Проверяем, есть ли сейчас элементы, соответствующие вашему селектору
              const targetElementNow = document.querySelector(selector);

              if (targetElementNow) {
                // Если элемент найден, останавливаем отслеживание и запускаем скрипт
                observer.disconnect();
                workFunction();
              }
            });

            // Начинаем отслеживание изменений в корне документа и его потомках
            observer.observe(document.documentElement, {
              childList: true,
              subtree: true,
            });
          }
        }
        /////// Ожидание появления селектора
        return true;
      },
      bind_actions: function () {
        return true;
      },
      render: function () {
        return true;
      },
      contacts: {
        selected: function () {},
      },
      leads: {
        selected: function () {},
      },
      onSave: function () {
        return true;
      },
    };
    return this;
  };
  return CustomWidget;
});
